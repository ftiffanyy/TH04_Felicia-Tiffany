﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_Felicia_Tiffany
{
    public partial class Form1 : Form
    {
        List<team> tim;
        List<string> country;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<player> playerteam1 = new List<player>
            {
                new player("13", "Inaki Pena", "GK"),
                new player("4", "Ronald Araujo", "DF"),
                new player("15", "Andreas Christensen", "DF"),
                new player("17", "Marcos Alonso", "DF"),
                new player("23", "Jules Kounde", "DF"),
                new player("6", "Gavi", "MF"),
                new player("8", "Pedri", "MF"),
                new player("20", "Sergi Roberto", "MF"),
                new player("7", "Ferran Torres", "FW"),
                new player("9", "Robert Lewandowski", "FW"),
                new player("11", "Raphinha", "FW")
            };

            List<player> playerteam2 = new List<player>
            {
                new player("18", "Stefan Ortega", "GK"),
                new player("2", " Kyle Walker", "DF"),
                new player("5", "John Stones", "DF"),
                new player("21", "Sergio Gómez", "DF"),
                new player("25", "Manuel Akanji", "DF"),
                new player("16", "Rodri", "MF"),
                new player("17", "Kevin De Bruyne", "MF"),
                new player("47", "Phil Foden", "MF"),
                new player("52", "Oscar Bobb", "MF"),
                new player("9", "Erling Haaland", "FW"),
                new player("19", "Julián Álvarez", "FW")
            };

            List<player> playerteam3 = new List<player>
            {
                new player("1", "Alisson Becker", "GK"),
                new player("2", "Joe Gomez", "DF"),
                new player("5", "Ibrahima Konate", "DF"),
                new player("26", "Andrew Robertson", "DF"),
                new player("84", "Conor Bradley", "DF"),
                new player("6", "Thiago Alcantara", "MF"),
                new player("17", "Curtis Jones", "MF"),
                new player("19", "Harvey Eliott", "MF"),
                new player("7", "Luis Diaz", "FW"),
                new player("11", "Mohamed Salah", "FW"),
                new player("50", "Ben Doak", "FW")
            };
            team team1 = new team("Barcelona", "Spain", "Barcelona", playerteam1);
            team team2 = new team("Manchester City", "England", "Manchester", playerteam2);
            team team3 = new team("Liverpool", "England", "Liverpool", playerteam3);
            tim = new List<team> {team1, team2, team3};
            country = new List<string> {"Spain", "England"};
            cb_country.DataSource = country;
            cb_country.SelectedIndex = -1;
            cb_team.SelectedIndex = -1;
            lb_player.Items.Clear();
        }

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            string choosecountry = (string)cb_country.SelectedItem;
            List<team> isiteam = new List<team>();
            foreach(team x in tim)
            {
                if (x.Teamcountry == choosecountry)
                {
                    isiteam.Add(x);
                }
            }
            cb_team.DataSource = isiteam;
            cb_team.DisplayMember = "teamname";
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            lb_player.Items.Clear();
            team chooseteam = (team)cb_team.SelectedItem;
            if (chooseteam.Players !=  null)
            {
                foreach(player x in chooseteam.Players)
                {
                    lb_player.Items.Add("[" + x.Playernumber + "] " + x.Playername + ", " + x.Playerposition);
                }
            }
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            if (tb_teamname.Text == "" || tb_country.Text == "" || tb_city.Text == "")
            {
                MessageBox.Show("All fields must not be empty!!!", "!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                bool yn = true;
                foreach(team x in tim)
                {
                    if (x.Teamname == tb_teamname.Text)
                    {
                        yn = false;
                        break;
                    }
                }
                if (yn == false)
                {
                    MessageBox.Show("Team Name Already Exist!!");
                }
                else
                {
                    team teambaru = new team(tb_teamname.Text, tb_country.Text, tb_city.Text, new List<player>());
                    tim.Add(teambaru);
                    cb_country.SelectedIndex = -1;
                    if (!country.Contains(tb_country.Text))
                    {
                        country.Add(tb_country.Text);
                        cb_country.DataSource = null;
                        cb_country.DataSource = country;
                    }
                    tb_teamname.Text = "";
                    tb_country.Text = "";
                    tb_city.Text = "";
                }
            }
        }

        private void bt_addplayer_Click(object sender, EventArgs e)
        {
            if (tb_name.Text == "" || tb_number.Text == "" || (string)cb_position.SelectedItem == "")
            {
                MessageBox.Show("All fields must not be empty!!!", "!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                bool yn = true;
                team chooseteam = (team)cb_team.SelectedItem;
                string position = (string)cb_position.SelectedItem;
                player playerbaru = new player(tb_number.Text, tb_name.Text, position);
                foreach(player x in chooseteam.Players)
                {
                    if (x.Playername == tb_name.Text || x.Playernumber == tb_number.Text)
                    {
                        yn = false;
                        break;
                    }
                }
                if (yn == false)
                {
                    MessageBox.Show("Player Name or Num Already Exist!!");
                }
                else
                {
                    chooseteam.Players.Add(playerbaru);
                    lb_player.Items.Clear();
                    foreach(player y in chooseteam.Players)
                    {
                        lb_player.Items.Add("[" + y.Playernumber + "] " + y.Playername + ", " + y.Playerposition);
                    }
                    tb_name.Text = "";
                    tb_number.Text = "";
                    cb_position.SelectedIndex = -1;
                }
            }
        }

        private void bt_remove_Click(object sender, EventArgs e)
        {
            int pencet = lb_player.SelectedIndex;
            team chooseteam = (team)cb_team.SelectedItem;
            if (chooseteam.Players.Count > 11)
            {
                chooseteam.Players.RemoveAt(pencet);
                lb_player.Items.Clear();
                foreach(player x in chooseteam.Players)
                {
                    lb_player.Items.Add("[" + x.Playernumber + "] " + x.Playername + ", " + x.Playerposition);
                }
            }
            else
            {
                MessageBox.Show("Number of players less than 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
