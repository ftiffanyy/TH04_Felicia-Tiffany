﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Felicia_Tiffany
{
    internal class team
    {
        private string teamname;
        private string teamcountry;
        private string teamcity;
        private List<player> players;

        public team(string teamname, string teamcountry, string teamcity, List<player> players)
        {
            this.teamname = teamname;
            this.teamcountry = teamcountry;
            this.teamcity = teamcity;
            this.players = players;
        }

        public string Teamname { get => teamname; set => teamname = value; }
        public string Teamcountry { get => teamcountry; set => teamcountry = value; }
        public string Teamcity { get => teamcity; set => teamcity = value; }
        internal List<player> Players { get => players; set => players = value; }
    }
    
}
