﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Felicia_Tiffany
{
    internal class player
    {
        private string playernumber;
        private string playername;
        private string playerposition;

        public player(string playernumber, string playername, string playerposition)
        {
            this.playernumber = playernumber;
            this.playername = playername;
            this.playerposition = playerposition;
        }

        public string Playernumber { get => playernumber; set => playernumber = value; }
        public string Playername { get => playername; set => playername = value; }
        public string Playerposition { get => playerposition; set => playerposition = value; }
    }
}
